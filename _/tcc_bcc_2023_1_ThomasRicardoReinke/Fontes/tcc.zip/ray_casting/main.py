import pygame
import sys
import math
from pygame.math import Vector2

import cProfile

sys.path.append('..')

from variables import vector_screen
from map import Map
from player import Player, PlayerDirection
from src.casters.dda import RayCastDDA
from src.casters.pixel import RayCastIncreasingDistance
from src.casters.vertices import RayCastVertices

clock = pygame.time.Clock()

map_object = Map()
player_object = Player(map_object, math.pi, math.pi / 3)

rays = 120

raycast_increasing_distance = RayCastIncreasingDistance(map_object, player_object.max_depth, player_object.fov, rays)
raycast_dda = RayCastDDA(map_object, player_object.max_depth, player_object.fov, rays)
raycast_vertices = RayCastVertices()
selected_algorithm = raycast_dda

while True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit(0)
            
        if pygame.mouse.get_pressed()[0]:
            try:
                x, y = pygame.mouse.get_pos()
                player_object.need_to_cast = True
                map_object.change_tile(Vector2(x, y))
            except AttributeError:
                pass
            # if event.button == 3:
            #     

    pygame.draw.rect(map_object.window, (0, 0, 0), (0, 0, vector_screen.y, vector_screen.y))
    
    map_object.build_map()
    
    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]: player_object.move(PlayerDirection.LEFT); player_object.need_to_cast = True
    if keys[pygame.K_RIGHT]: player_object.move(PlayerDirection.RIGHT); player_object.need_to_cast = True
    if keys[pygame.K_UP]: player_object.move(PlayerDirection.UP); player_object.need_to_cast = True
    if keys[pygame.K_DOWN]: player_object.move(PlayerDirection.DOWN); player_object.need_to_cast = True
    
    if keys[pygame.K_w]: player_object.change_angle(PlayerDirection.UP); player_object.need_to_cast = True
    if keys[pygame.K_a]: player_object.change_angle(PlayerDirection.LEFT); player_object.need_to_cast = True
    if keys[pygame.K_s]: player_object.change_angle(PlayerDirection.DOWN); player_object.need_to_cast = True
    if keys[pygame.K_d]: player_object.change_angle(PlayerDirection.RIGHT); player_object.need_to_cast = True
    
    if keys[pygame.K_1]: selected_algorithm = raycast_increasing_distance
    if keys[pygame.K_2]: selected_algorithm = raycast_dda
    if keys[pygame.K_3]: selected_algorithm = raycast_vertices
    
    player_object.cast_rays(selected_algorithm)
    
    pygame.display.update()
    
    fps = clock.get_fps()
    pygame.display.set_caption(f'Raycasting: {fps} FPS')

    clock.tick()
