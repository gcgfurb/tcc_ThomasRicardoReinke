import pygame
from variables import vector_screen, Point
from pygame.math import Vector2

class Map(object):
    def __init__(self) -> None:
        self.window = pygame.display.set_mode((vector_screen.x, vector_screen.y))
        self.environment = [[0 for i in range(20)] for j in range(20)]
        
        self.block_border = 2
        self.ground_color = (100, 100, 100)
        self.wall_color = (200, 200, 200)
        self.visible_wall_color = (0, 255, 0)
        self.tile_size = int(vector_screen.x / len(self.environment))
        
        self.need_to_update = False
        self.last_changed = None

    def build_map(self) -> None:
                
        for row, places in enumerate(self.environment):
            for col in range(len(places)):
                
                block_color = self.ground_color
                block_border = 0
                
                if self.environment[row][col] == 1:
                    block_color = self.wall_color
                    block_border = self.block_border
                
                pygame.draw.rect(
                    self.window,
                    block_color,
                    (col * self.tile_size, row * self.tile_size, self.tile_size - block_border, self.tile_size - block_border)
                )
    
    def _translate_to_map_coords(self, col, row):
        return (int(col / self.tile_size), int(row / self.tile_size))
    
    def change_tile(self, coord):
        
        self.need_to_update = True
        
        x, y= self._translate_to_map_coords(coord.x, coord.y)
        
        if self.last_changed is not None and self.last_changed.x == x and self.last_changed.y == y:
            return

        self.last_changed = Vector2(x, y)
        self.environment[y][x] = 0 if self.environment[y][x] else 1

    def get_points(self) -> tuple[list[tuple[Vector2]], list[Vector2]]:
        # 1 ---- 2
        # |      |
        # |      |
        # 3 ---- 4
        
        upper_left = Vector2(0, 0)
        upper_right = Vector2(vector_screen.x, 0)
        lower_right = Vector2(vector_screen.x, vector_screen.y)
        lower_left = Vector2(0, vector_screen.y)
        
        map_points = [(upper_left, upper_right, lower_right, lower_left)]

        for row, places in enumerate(self.environment):
            for col in range(len(places)):
        
                if self.environment[row][col] == 1:
                    point_1 = Vector2(col * self.tile_size, row * self.tile_size)
                    point_2 = Vector2((col + 1) * self.tile_size, row * self.tile_size)
                    point_3 = Vector2(col * self.tile_size, (row + 1) * self.tile_size)
                    point_4 = Vector2((col + 1) * self.tile_size, (row + 1) * self.tile_size)
              
                    map_points.append((point_1, point_2, point_4, point_3))
                
        return map_points