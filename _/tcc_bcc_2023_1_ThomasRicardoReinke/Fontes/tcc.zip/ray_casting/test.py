import time, sys

sys.path.append('..')

from ray_casting.src.casters.dda import RayCastDDA
from ray_casting.src.casters.pixel import RayCastIncreasingDistance
from ray_casting.src.casters.vertices import RayCastVertices
from ray_casting.map import Map
from ray_casting.player import Player
import math

if __name__ == '__main__':
    
    map_object = Map()
    player_object = Player(map_object, math.pi, math.pi / 3)

    rays = 100

    raycast_increasing_distance = RayCastIncreasingDistance(map_object, player_object.max_depth, player_object.fov, rays)
    raycast_dda = RayCastDDA(map_object, player_object.max_depth, player_object.fov, rays)
    raycast_vertices = RayCastVertices()
    selected_algorithm = raycast_dda
    
    total = 0
    
    lista = [(150, 300), (150, 450), 
             (100, 300), (100, 450),
             (75, 300), (75, 450),
             (50, 300), (50, 450),
             (25, 300), (25, 450)
             ]
    
    for i in lista:
        
        print()
        print()
        print(f'Rays: {i[0]} | Distance: {i[1]}')
        for x in range(50):
            start_time = time.time()
            raycast_increasing_distance = RayCastIncreasingDistance(map_object, i[1], player_object.fov, i[0])
            player_object.cast_rays(raycast_increasing_distance)
            tempo = (time.time() - start_time) * 1000
            # print(f'    {i}: {tempo} milissegundos ---')
            total += tempo
        print(f'Pixel')
        print(f'--- {total / 50} milissegundos ---')
        print('')
        
        total = 0
        
        for x in range(50):
            start_time = time.time()
            raycast_dda = RayCastDDA(map_object, i[1], player_object.fov, i[0])
            player_object.cast_rays(raycast_dda)
            tempo = (time.time() - start_time) * 1000
            # print(f'    {i}: {tempo} milissegundos ---')
            total += tempo
        print(f'DDA')
        print(f'--- {total / 50} milissegundos ---')
        print('')