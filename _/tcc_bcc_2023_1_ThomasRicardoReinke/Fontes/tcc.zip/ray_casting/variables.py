from pygame.math import Vector2

vector_screen = Vector2(680, 680)

class Point(object):
    def __init__(self, x: int, y: int) -> None:
        self.x = x
        self.y = y
        self.angle = 0
        self.param = None
        
    def __str__(self):
        return f'x: {self.x}, y: {self.y}, angle: {self.angle}'