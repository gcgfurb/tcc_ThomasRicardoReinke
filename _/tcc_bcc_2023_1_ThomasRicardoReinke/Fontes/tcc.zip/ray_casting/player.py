import math
from enum import Enum
from map import Map
import pygame
from src.casters.contract import RayCastApproach
import time

class PlayerDirection(Enum):
    UP = 1
    DOWN = 2
    RIGHT = 3
    LEFT = 4

class Player():
    def __init__(self, map: Map, angle: int, fov: int) -> None:
        self.map = map
        self.angle = angle
        self.fov = fov
        self.x = self.map.window.get_width() / 2
        self.y = self.map.window.get_height() / 2
        self.max_depth = 300
        self.need_to_cast = False
        
        self.runned = 0
        self.total_time = 0
    
    def _draw_player(self):
        target_x = self.x - math.sin(self.angle) * self.map.tile_size / 1.5
        target_y = self.y + math.cos(self.angle) * self.map.tile_size / 1.5
        
        pygame.draw.line(self.map.window, (255, 0, 0), (self.x, self.y), (target_x, target_y), 5)
        pygame.draw.circle(self.map.window, (255, 0, 0), (self.x, self.y), self.map.tile_size / 2)
    
    def cast_rays(self, ray_caster: RayCastApproach):
        if self.need_to_cast:   
            points = self.map.get_points()
            ray_caster.run(self.angle, self.x, self.y, points)

        ray_caster.draw(self.map.window)
        ray_caster.draw_collision(self.map.window)
        
        self.need_to_cast = False
        self._draw_player()
            
    def move(self, direction: PlayerDirection):
        if direction == PlayerDirection.UP:
            self._check_colision(-math.sin(self.angle) * 5, math.cos(self.angle) * 5)
            
        if direction == PlayerDirection.DOWN:
            self._check_colision(-(-math.sin(self.angle) * 5), -(math.cos(self.angle) * 5))
            
        if direction == PlayerDirection.RIGHT:
            self.angle += 0.1
            
        if direction == PlayerDirection.LEFT:
            self.angle -= 0.1
            
        self.map.need_to_update = True
            
    def change_angle(self, direction: PlayerDirection):
        if direction == PlayerDirection.UP:
            self.angle = math.pi
            
        if direction == PlayerDirection.DOWN:
            self.angle = math.pi * 2
            
        if direction == PlayerDirection.RIGHT:
            self.angle = math.pi + (math.pi / 2)
            
        if direction == PlayerDirection.LEFT:
            self.angle = math.pi - (math.pi / 2)
            
    def _check_colision(self, x, y):
        column, row = self.map._translate_to_map_coords(self.x + x, self.y + y)
        
        if column >= len(self.map.environment[0]) or row >= len(self.map.environment):
            return
        
        if self.map.environment[row][column] != 1:
            self.x += x
            self.y += y
