class Line:
    def __init__(self, color: tuple, start_pos: tuple, end_pos: tuple) -> None:
        self.color = color
        self.start_pos = start_pos
        self.end_pos = end_pos