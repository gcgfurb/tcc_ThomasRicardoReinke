from ray_casting.map import Map
from .contract import RayCastApproach
import pygame.gfxdraw
import math
from pygame.math import Vector2

class RayCastVertices(RayCastApproach):
    def __init__(self) -> None:
        super().__init__(None, 0, 0, 0)
        self.unique_points = []
        
    def run(self, angle: float, player_x: int, player_y: int, map_points: list[Vector2]):
        self.draw_points = []
        polygons = map_points
        
        points = [(point, polygon[(i + 1) % len(polygon)])
                    for polygon in polygons
                    for i, point in enumerate(polygon)]

        unique_points = []
        for point in points:
            if point not in unique_points: unique_points.append(point)
            
        self.unique_points = unique_points

        unique_angles: list[float] = []
        for point in unique_points:
            angle = math.atan2(point[0].y - player_y, point[0].x - player_x)
            unique_angles.append(angle - 0.00001)
            unique_angles.append(angle)
            unique_angles.append(angle + 0.00001)

        intersects = []
        
        for angle in unique_angles:
            dx = math.cos(angle)
            dy = math.sin(angle)
            
            ray = (Vector2(player_x, player_y), Vector2(player_x + dx, player_y + dy))
            
            closes_intersect = None
            
            for polygon in points:
                intersect = self._get_intersection(ray, polygon)
                if intersect is None: continue
                if closes_intersect is None or intersect['param'] < closes_intersect['param']:
                    closes_intersect = intersect
                        
            if closes_intersect is None: continue
            closes_intersect['angle'] = angle
            
            intersects.append(closes_intersect)
            
        intersects = sorted(intersects, key = lambda k: k['angle'])
        
        for i in intersects:
            self.draw_points.append(((255, 255, 0), (player_x, player_y), (i['x'], i['y'])))
            # pygame.draw.line(self.map.window, (255, 255, 0), (player_x, player_y), (i['x'], i['y']))
            
            
        # self.draw_polygon(intersects, (255, 255, 0))
        # print("--- %s seconds ---" % (time.time() - start_time))
        
    def _get_intersection(self, ray: tuple[Vector2], segment: tuple[Vector2]):
        
        # RAY in parametric: Point + Delta * T1
        r_px = ray[0].x
        r_py = ray[0].y
        r_dx = ray[1].x - ray[0].x
        r_dy = ray[1].y - ray[0].y

        # SEGMENT in parametric: Point + Direction * T2
        s_px = segment[0].x
        s_py = segment[0].y
        s_dx = segment[1].x - segment[0].x
        s_dy = segment[1].y - segment[0].y

        # Are they parallel? If so, no intersect
        r_mag = math.sqrt(r_dx * r_dx + r_dy * r_dy)
        s_mag = math.sqrt(s_dx * s_dx + s_dy * s_dy)
        if r_dx / r_mag == s_dx / s_mag and r_dy / r_mag == s_dy / s_mag:
            return None

        try:
            T2 = (r_dx * (s_py - r_py) + r_dy * (r_px - s_px)) / (s_dx * r_dy - s_dy * r_dx)
        except ZeroDivisionError:
            T2 = (r_dx * (s_py - r_py) + r_dy * (r_px - s_px)) / (s_dx * r_dy - s_dy * r_dx - 0.00001)
            
        try:
            T1 = (s_px + s_dx * T2 - r_px) / r_dx
        except ZeroDivisionError:
            T1 = (s_px + s_dx * T2 - r_px) / (r_dx - 0.00001)

        # Must be within parametic whatevers for RAY/SEGMENT
        if T1 < 0: return None
        if T2 < 0 or T2 > 1: return None

        # Return the POINT OF INTERSECTION
        return {
            "x": r_px + r_dx * T1,
            "y": r_py + r_dy * T1,
            "param": T1
        }
        
    def draw_polygon(self, polygon, color, surface: pygame.Surface):
        # collect coordinates for a giant polygon
        points = []
        for intersect in polygon:
            points.append((intersect['x'], intersect['y']))
        
        # draw as a giant polygon
        pygame.gfxdraw.aapolygon(surface, points, color)
        pygame.gfxdraw.filled_polygon(surface, points, color)
        
    def draw(self, surface: pygame.Surface):
        points = []
        for i in self.draw_points:
            points.append({'x': i[2][0], 'y': i[2][1]})
        
        if len(points): self.draw_polygon(points, (255, 255, 0), surface)