import pygame
import math
from pygame.math import Vector2
from .contract import RayCastApproach
from ray_casting.map import Map

class RayCastDDA(RayCastApproach):
    def __init__(self, map: Map, max_depth: int, fov: int, rays: int) -> None:
        super().__init__(map, max_depth, fov, rays)

    def run(self, player_angle: float, player_x: int, player_y: int, points = []):
        self.draw_points = []
        self.draw_blocks = []
        
        start_angle = player_angle - (self.fov / 2)

        for ray in range(self.casted_rays):
            
            target = Vector2(player_x - math.sin(start_angle) * (self.max_depth), player_y + math.cos(start_angle) * (self.max_depth))
            player = Vector2(player_x, player_y)
                        
            player_in_map = Vector2(player_x // self.map.tile_size, player_y // self.map.tile_size)
                    
            ray_start = Vector2(player_in_map.x, player_in_map.y)
            normalized_direction = (target - player).normalize()
            normalized_direction.x -= 0.0000001
            normalized_direction.y -= 0.0000001
            
            ray_stepsize = Vector2(
                math.sqrt(1 + math.pow((normalized_direction.y / normalized_direction.x), 2)), 
                math.sqrt(1 + math.pow((normalized_direction.x / normalized_direction.y), 2))
            )
            
            map_position = Vector2(player_in_map.x, player_in_map.y)
            
            ray_length = Vector2(0, 0)
            step = Vector2(0, 0)
            
            if (normalized_direction.x < 0):
                step.x = -1
                ray_length.x = (ray_start.x - map_position.x) * ray_stepsize.x
            else:
                step.x = 1
                ray_length.x = ((map_position.x + 1) - ray_start.x) * ray_stepsize.x

            if (normalized_direction.y < 0):
                step.y = -1
                ray_length.y = (ray_start.y - map_position.y) * ray_stepsize.y
            else:
                step.y = 1
                ray_length.y = ((map_position.y + 1) - ray_start.y) * ray_stepsize.y
            
            found_block = False
            distance = 0
            
            while (distance * self.map.tile_size) < self.max_depth - 50:
                if ray_length.x < ray_length.y:
                    map_position.x += step.x
                    distance = ray_length.x
                    ray_length.x += ray_stepsize.x
                else:
                    map_position.y += step.y
                    distance = ray_length.y
                    ray_length.y += ray_stepsize.y
                    

                if map_position.x >= 0 and map_position.x < len(self.map.environment[0]) and \
                   map_position.y >= 0 and map_position.y < len(self.map.environment):
                                              
                    pygame.draw.circle(self.map.window, (255, 255, 0), (map_position.x * self.map.tile_size, map_position.y * self.map.tile_size), 2)
                    if (self.map.environment[int(map_position.y)][int(map_position.x)] == 1):
                        intersection_point = Vector2(0, 0)
                        found_block = True
                        break
                        
            if (found_block):
                intersection_point = ray_start + normalized_direction * distance
                
                distance = math.dist([player_x, player_y], [intersection_point.x * self.map.tile_size, intersection_point.y * self.map.tile_size])
                color = (distance * 255) / (self.map.window.get_height() * 2)
                                
                # pygame.draw.rect(self.map.window, (color / 2, color, color / 2), (
                #     map_position.x * self.map.tile_size,
                #     map_position.y * self.map.tile_size,
                #     self.map.tile_size - self.map.block_border,
                #     self.map.tile_size - self.map.block_border
                # ))
                
                self.draw_blocks.append(((color / 2, color, color / 2), (
                    map_position.x * self.map.tile_size,
                    map_position.y * self.map.tile_size,
                    self.map.tile_size - self.map.block_border,
                    self.map.tile_size - self.map.block_border
                )))

            start_angle += self.fov / self.casted_rays