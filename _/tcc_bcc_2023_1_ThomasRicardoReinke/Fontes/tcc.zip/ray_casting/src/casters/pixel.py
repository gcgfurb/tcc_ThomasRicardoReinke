from .contract import RayCastApproach
from pygame.math import Vector2
import math
import pygame
from ray_casting.map import Map

class RayCastIncreasingDistance(RayCastApproach):
    def __init__(self, map: Map, max_depth: int, fov: int, rays: int) -> None:
        super().__init__(map, max_depth, fov, rays)

    def run(self, player_angle: float, player_x: int, player_y: int, points = []):
        self.draw_points = []
        self.draw_blocks = []
        
        start_angle = player_angle - (self.fov / 2)
        
        number_of_cols = len(self.map.environment[0])
        number_of_rows = len(self.map.environment)
        
        for ray in range(self.casted_rays):
            
            target_sin = math.sin(start_angle)
            target_cos = math.cos(start_angle)
            
            for depth in range(self.max_depth):

                target = Vector2(player_x - target_sin * depth, player_y + target_cos * depth)

                col, row = self.map._translate_to_map_coords(target.x, target.y)
                
                if col >= number_of_cols or row >= number_of_rows:
                    self.draw_points.append(((255, 255, 0), (player_x, player_y), (target.x, target.y)))
                    continue

                if self.map.environment[row][col] == 1:
                    
                    distance = math.dist([player_x, player_y], [target.x, target.y])
                    color = (distance * 255) / (self.map.window.get_height() * 2)
                    
                    self.draw_blocks.append(((color / 2, color, color / 2), (
                        col * self.map.tile_size,
                        row * self.map.tile_size,
                        self.map.tile_size - self.map.block_border,
                        self.map.tile_size - self.map.block_border
                    )))
                    
                    # pygame.draw.rect(self.map.window, (color / 2, color, color / 2), (
                    #     col * self.map.tile_size,
                    #     row * self.map.tile_size,
                    #     self.map.tile_size - self.map.block_border,
                    #     self.map.tile_size - self.map.block_border
                    # ))

                    self.draw_points.append(((255, 255, 0), (player_x, player_y), (target.x, target.y)))
                    # pygame.draw.line(self.map.window, (255, 255, 0), (player_x, player_y), (target.x, target.y))
                    break
                
                if depth == self.max_depth - 1:
                    self.draw_points.append(((255, 255, 0), (player_x, player_y), (target.x, target.y)))
                    # pygame.draw.line(self.map.window, (255, 255, 0), (player_x, player_y), (target.x, target.y))
                    break

            start_angle += self.fov / self.casted_rays