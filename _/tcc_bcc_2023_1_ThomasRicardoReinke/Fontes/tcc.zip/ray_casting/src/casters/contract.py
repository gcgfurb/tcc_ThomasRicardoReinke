import abc
import pygame
from ray_casting.map import Map

class RayCastApproach(metaclass=abc.ABCMeta):
    def __init__(self, map: Map, max_depth: int, fov: int, rays: int) -> None:
        self.max_depth = max_depth
        self.fov = fov
        self.casted_rays = rays
        self.map = map
        self.draw_points: list[tuple[tuple, tuple, tuple]] = []
        self.draw_blocks: list = []
    
    @abc.abstractmethod
    def run(self, player_angle: float, player_x: int, player_y: int, points: list = []):
        return
    
    def draw(self, surface: pygame.Surface):
        for points in self.draw_points:
            pygame.draw.line(surface, points[0], points[1], points[2])
            
    def draw_collision(self, surface: pygame.Surface):
        for block in self.draw_blocks:
            pygame.draw.rect(surface, block[0], block[1])