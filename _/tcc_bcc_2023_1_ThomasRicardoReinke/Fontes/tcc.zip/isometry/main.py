import pygame, sys
from pygame.locals import *
from pygame.math import Vector2

sys.path.append('..')

pygame.init()
pygame.display.set_caption('Demonstração - WFC + Ray Casting | Projeção Isométrica')

from src.game.main import IsometricGame
from src.utils import *
from src.constants import *


def main () :
    type_of_tree = 0
    looping = True
    
    game = IsometricGame()
    game.create_map(25, 25)
    walk_pressed = None
    key_pressed = None

    while looping :
        for event in pygame.event.get() :
            if event.type == QUIT :
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONUP:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                click_vector = Vector2(mouse_x - game.offset.x, mouse_y - game.offset.y)
                
                game.add_tree('.\\images\\tree.png', click_vector)
                    
            if event.type == pygame.KEYDOWN:
                walk_pressed = event.key
                key_pressed = event.key
                
        mouse_x, mouse_y = pygame.mouse.get_pos()
        mouse_pos = Vector2(mouse_x, mouse_y)
                
        if walk_pressed is not None:
            pressed = pygame.key.get_pressed()

            if pressed[K_w]: game.update_offset(0, 5)
            if pressed[K_a]: game.update_offset(5, 0)
            if pressed[K_s]: game.update_offset(0, -5)
            if pressed[K_d]: game.update_offset(-5, 0)
            
        if key_pressed is not None:
            pressed = pygame.key.get_pressed()
            
            if pressed[K_F3]: game.debug()
            key_pressed = None
        
        game.run()
        
        MAIN_SURFACE.blit(pygame.transform.scale(game.display, (WINDOW_WIDTH, WINDOW_HEIGHT)), (0, 0))   
        
        pygame.display.update()
        CLOCK.tick()
 
main()