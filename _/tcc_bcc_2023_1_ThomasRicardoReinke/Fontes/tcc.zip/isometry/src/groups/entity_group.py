import pygame
from pygame.math import Vector2

class EntityGroup(pygame.sprite.Group):
    def __init__(self) -> None:
        super().__init__()
        
    def draw(self, offset: Vector2, surface: pygame.Surface):
        sprites = self.sprites()
        
        for sprite in sorted(sprites, key = lambda spr: spr.pos.y):
            rect = sprite.rect
            new_rect = (rect[0] + offset.x, rect[1] + offset.y, rect[2], rect[3])
            
            self.spritedict[sprite] = surface.blit(sprite.image, new_rect)
            
        self.lostsprites = []
        
    def update(self):
        # return
        sprites = self.sprites()
        
        # for sprite in sprites:
        #     orig_x, orig_y = sprite.image.get_size()
        #     size_x = orig_x + round(scale)
        #     size_y = orig_y + round(scale)
        #     sprite.image = pygame.transform.scale(sprite.image, (size_x, size_y))
        #     sprite.rect = sprite.image.get_rect(center = sprite.rect.center)