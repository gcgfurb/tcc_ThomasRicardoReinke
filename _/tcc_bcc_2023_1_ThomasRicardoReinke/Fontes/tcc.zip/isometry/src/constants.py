import pygame
from pygame.math import Vector2

# Colours
BACKGROUND = (0, 0, 0)
SHADOW = (100, 100, 100)

# Game Setup
CLOCK = pygame.time.Clock()
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 900

VECTOR_TILESIZE = Vector2(100, 50) # 100 50
VECTOR_ORIGIN = Vector2(3, 1)

MAIN_SURFACE = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
COVER_SURFACE = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
COVER_SURFACE.convert_alpha()
COVER_SURFACE.set_colorkey((255, 255, 255))

FONT = pygame.font.Font('freesansbold.ttf', 16)