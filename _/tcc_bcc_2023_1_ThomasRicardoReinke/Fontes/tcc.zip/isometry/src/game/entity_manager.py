from src.game.chunk_manager import ChunkManager

from src.groups.entity_group import EntityGroup
from src.entity.tree import Tree

from src.constants import VECTOR_TILESIZE

from pygame.math import Vector2
from pygame import Surface
import pygame

class EntityManager:
    def __init__(self) -> None:
        self.entity_group = EntityGroup()
        
    def add_entity(self, sprite: str, position: Vector2):
        new_tile = Tree(sprite, position)
        self.entity_group.add(new_tile)
                            
    def draw(self, offset: Vector2, surface: Surface) -> None:
        self.entity_group.draw(offset, surface)