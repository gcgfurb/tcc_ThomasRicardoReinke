import time
import pygame

from pygame.math import Vector2
from isometry.src.utils import to_list_coordinates, to_screen_coordinates, is_point_inside
from src.constants import VECTOR_TILESIZE, WINDOW_HEIGHT, WINDOW_WIDTH, BACKGROUND, FONT, CLOCK, COVER_SURFACE, SHADOW

from src.game.chunk_manager import ChunkManager
from src.game.tiles_manager import TilesManager
from src.game.entity_manager import EntityManager
from src.ray_cast import RayCastVertices

from src.entity.tree import Tree

from wfc.wave_function_collapse import WaveFunctionCollapse

class IsometricGame:
    def __init__(self) -> None:
        self.offset = Vector2(0, 0)
        self.display = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        
        self.col_nums = 0
        self.row_nums = 0
        
        self.object_points = []
        self.chunk_manager = ChunkManager(8, 3)
        self.tiles_manager = TilesManager()
        self.entity_manager = EntityManager()
        self.ray_cast = RayCastVertices()
        
        self.vector_selected = Vector2()
        
        self.debugging = True
        
    def draw_selected_block(self, mouse: Vector2):
        vector_cell = Vector2((mouse.x - self.offset.x) // VECTOR_TILESIZE.x, (mouse.y - self.offset.y) // VECTOR_TILESIZE.y)
        vector_selected = to_list_coordinates(vector_cell.x, vector_cell.y)
        
        vector_selected_point = to_screen_coordinates(vector_selected.x, vector_selected.y, self.offset)
        
        mediana_w = Vector2(vector_selected_point.x + (VECTOR_TILESIZE.x / 2), vector_selected_point.y)
        mediana_h = Vector2(vector_selected_point.x, vector_selected_point.y + (VECTOR_TILESIZE.y / 2))
        
        # upper corner left
        if is_point_inside(mouse, mediana_w, vector_selected_point, mediana_h):
            vector_selected.x -= 1

        # lower corner left
        elif is_point_inside(
            mouse, 
            Vector2(mediana_w.x, mediana_w.y + VECTOR_TILESIZE.y), 
            Vector2(vector_selected_point.x, vector_selected_point.y + VECTOR_TILESIZE.y), 
            mediana_h
        ):
            vector_selected.y += 1
            
        # upper corner right
        elif is_point_inside(
            mouse,
            mediana_w,
            Vector2(vector_selected_point.x + VECTOR_TILESIZE.x, vector_selected_point.y), 
            Vector2(mediana_h.x + VECTOR_TILESIZE.x, mediana_h.y),
        ):
            vector_selected.y -= 1
                        
        # lower corner right
        elif is_point_inside(
            mouse,
            Vector2(mediana_w.x, mediana_w.y + VECTOR_TILESIZE.y),
            Vector2(vector_selected_point.x + VECTOR_TILESIZE.x, vector_selected_point.y + VECTOR_TILESIZE.y), 
            Vector2(mediana_h.x + VECTOR_TILESIZE.x, mediana_h.y),
        ):
            vector_selected.x += 1
            
        self.vector_selected = vector_selected
        self.chunk_manager.selected_chunk = Vector2(self.vector_selected.x // self.chunk_manager.CHUNK_SIZE, self.vector_selected.y // self.chunk_manager.CHUNK_SIZE)

        vector_selected_screen = to_screen_coordinates(vector_selected.x, vector_selected.y, self.offset)
                
        self.tiles_manager.draw_selected(vector_selected_screen, self.display)
        
    def create_map(self, size_x: int, size_y: int):
        wave_function = WaveFunctionCollapse()
        map_array = wave_function.run(size_x, size_y)
        
        while map_array is False:
            map_array = wave_function.run(size_x, size_y)
        
        image_list = {}
        
        self.col_nums = len(map_array[0])
        self.row_nums = len(map_array)
        
        for row in range(self.row_nums):
            for col in range(self.col_nums):
                
                if 'stone' in map_array[row][col].sprite:
                    filename = 'stone.png'
                elif 'water' in map_array[row][col].sprite:
                    filename = 'water.png'
                elif 'grass' in map_array[row][col].sprite:
                    filename = 'grass.png'
                  
                vector_world = to_screen_coordinates(col, row, self.offset)
                
                if filename not in image_list:
                    image = pygame.image.load(f'.\\images\\tiles\\{filename}').convert_alpha()
                    image = pygame.transform.scale(image, (VECTOR_TILESIZE.x, VECTOR_TILESIZE.y * 1.5))
                
                    image_list[filename] = image
                
                chunk_x = col // self.chunk_manager.CHUNK_SIZE
                chunk_y = row // self.chunk_manager.CHUNK_SIZE
                target_chunk = f'{chunk_x},{chunk_y}'
                
                if target_chunk not in self.chunk_manager.map_dict:
                    self.chunk_manager.map_dict[target_chunk] = self.chunk_manager.create_empty_chunk()
                    
                self.chunk_manager.map_dict[target_chunk][row % self.chunk_manager.CHUNK_SIZE].append((image_list[filename], filename, vector_world))
                self.tiles_manager.add_tile(image_list[filename], vector_world)

    def draw_tiles(self):
        self.tiles_manager.define_rendered_tiles(self.chunk_manager)
        self.tiles_manager.draw(self.offset, self.display)
        
    def draw_entities(self):
        self.entity_manager.draw(self.offset, self.display)
        
    def draw_debug_info(self):
        fps = int(CLOCK.get_fps())
        
        mouse_x, mouse_y = pygame.mouse.get_pos()
        
        text_fps = FONT.render(f'FPS: {fps}', True, (255, 255, 255))
        text_mouse = FONT.render(f'Mouse: x {mouse_x} | y {mouse_y}', True, (255, 255, 255))
        text_selected = FONT.render(f'Tile Selecionado: x {self.vector_selected.x} | y {self.vector_selected.y}', True, (255, 255, 255))
        chunk_selected = FONT.render(f'CHUNK Selecionado: x {self.vector_selected.x // self.chunk_manager.CHUNK_SIZE} | y {self.vector_selected.y // self.chunk_manager.CHUNK_SIZE}', True, (255, 255, 255))
        
        self.display.blit(text_fps, (10, 10))
        self.display.blit(text_mouse, (10, 30))
        self.display.blit(text_selected, (10, 50))
        self.display.blit(chunk_selected, (10, 70))
        
    def draw_map(self):
        self.display.fill(BACKGROUND)
        self.draw_tiles()
        
        mouse_x, mouse_y = pygame.mouse.get_pos()
        mouse_pos = Vector2(mouse_x, mouse_y)

        self.draw_selected_block(mouse_pos)
            
    def draw_shadow(self):
        mouse_x, mouse_y = pygame.mouse.get_pos()
        mouse_pos = Vector2(mouse_x, mouse_y)
        
        # shadow collor
        COVER_SURFACE.fill(SHADOW)
        
        self.ray_cast.run(
            mouse_pos.x, 
            mouse_pos.y, 
            [(Vector2(0, 0), Vector2(WINDOW_WIDTH, 0), Vector2(WINDOW_WIDTH, WINDOW_HEIGHT), Vector2(0, WINDOW_HEIGHT))] + \
                self.object_points)
        self.ray_cast.draw(COVER_SURFACE, self.display, self.debugging)
        
        self.display.set_clip()
        self.display.blit(COVER_SURFACE, (0, 0), None, special_flags= pygame.BLEND_RGBA_MULT)
        
    def add_tree(self, sprite: str, position: Vector2):
        self.object_points.append((
            Vector2(position.x - 10 + self.offset.x, position.y + 50 + self.offset.y),
            Vector2(position.x + self.offset.x, position.y + 45 + self.offset.y),
            Vector2(position.x + 10 + self.offset.x, position.y + 50 + self.offset.y),
            Vector2(position.x + self.offset.x, position.y + 60 + self.offset.y)
        ))
        
        self.entity_manager.add_entity(sprite, position)

    def update_offset(self, x: int, y: int):
        for polygon in self.object_points:
            for vector in polygon:
                vector.x += x
                vector.y += y
                
        self.offset.x += x
        self.offset.y += y

    def create_shadow(self):
        vector_selected_screen = to_screen_coordinates(self.vector_selected.x, self.vector_selected.y, self.offset)
        
        self.object_points.append((
            Vector2(vector_selected_screen.x + VECTOR_TILESIZE.x / 2, vector_selected_screen.y),
            Vector2(vector_selected_screen.x + VECTOR_TILESIZE.x, vector_selected_screen.y + VECTOR_TILESIZE.y / 2),
            Vector2(vector_selected_screen.x + VECTOR_TILESIZE.x / 2, vector_selected_screen.y),
            Vector2(vector_selected_screen.x, vector_selected_screen.y + VECTOR_TILESIZE.y / 2),
        ))
        
        print(self.object_points)
        
    def draw_debug(self):
        self.chunk_manager.draw_visible_chunks_outline(self.offset, self.display)
        self.chunk_manager.draw_chunks_outlines(self.col_nums, self.row_nums, self.offset, self.display)
        self.draw_debug_info()
    
    def debug(self):
        self.debugging = not self.debugging
    
    def run(self):
        self.draw_map()
        self.draw_shadow()
        self.draw_entities()
        
        if self.debugging:
            self.draw_debug()