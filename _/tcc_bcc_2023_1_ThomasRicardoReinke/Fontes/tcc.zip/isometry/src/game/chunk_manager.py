from src.constants import VECTOR_TILESIZE
from isometry.src.utils import to_screen_coordinates

from pygame.math import Vector2
from pygame import Surface
import pygame

class ChunkManager:
    def __init__(self, chunk_size: int, render_distance: int) -> None:
        self.CHUNK_SIZE = chunk_size
        self.RENDER_DISTANCE = render_distance
        
        self.selected_chunk = Vector2()
        
        self.map_dict = {}
    
    def create_empty_chunk(self):
        return [[] * self.CHUNK_SIZE for i in range(self.CHUNK_SIZE)]
    
    def draw_chunks_outlines(self, col_num: int, row_num: int, offset: int, surface: Surface) -> None:
        cols = col_num // self.CHUNK_SIZE
        rows = row_num // self.CHUNK_SIZE
    
        for col in range(cols):
            for row in range(rows):
        
                vector = to_screen_coordinates(col * self.CHUNK_SIZE, row * self.CHUNK_SIZE, offset)
        
                pygame.draw.polygon(
                    surface, 
                    (0, 0, 255), 
                    (
                        (vector.x + VECTOR_TILESIZE.x / 2, vector.y),
                        (vector.x + VECTOR_TILESIZE.x * ((self.CHUNK_SIZE / 2) + 0.5), vector.y + VECTOR_TILESIZE.y * (self.CHUNK_SIZE / 2)),
                        (vector.x + VECTOR_TILESIZE.x / 2, vector.y + VECTOR_TILESIZE.y * self.CHUNK_SIZE),
                        (vector.x - VECTOR_TILESIZE.x * ((self.CHUNK_SIZE / 2) - 0.5), vector.y + VECTOR_TILESIZE.y * (self.CHUNK_SIZE / 2)),
                    ), 1
                )
                
    def draw_visible_chunks_outline(self, offset: int, surface: Surface) -> None: 
        upper_left_chunk = to_screen_coordinates((self.selected_chunk.x - self.RENDER_DISTANCE) * self.CHUNK_SIZE, (self.selected_chunk.y - self.RENDER_DISTANCE) * self.CHUNK_SIZE, offset)
        upper_right_chunk = to_screen_coordinates((self.selected_chunk.x + self.RENDER_DISTANCE) * self.CHUNK_SIZE, (self.selected_chunk.y - self.RENDER_DISTANCE) * self.CHUNK_SIZE, offset)
        lower_left_chunk = to_screen_coordinates((self.selected_chunk.x - self.RENDER_DISTANCE) * self.CHUNK_SIZE, (self.selected_chunk.y + self.RENDER_DISTANCE) * self.CHUNK_SIZE, offset)
        lower_right_chunk = to_screen_coordinates((self.selected_chunk.x + self.RENDER_DISTANCE) * self.CHUNK_SIZE, (self.selected_chunk.y + self.RENDER_DISTANCE) * self.CHUNK_SIZE, offset)
    
        pygame.draw.polygon(
            surface, 
            (0, 255, 0), 
            (
                (upper_left_chunk.x + VECTOR_TILESIZE.x / 2, upper_left_chunk.y),
                (upper_right_chunk.x + VECTOR_TILESIZE.x * ((self.CHUNK_SIZE / 2) + 0.5), upper_right_chunk.y + VECTOR_TILESIZE.y * (self.CHUNK_SIZE / 2)),
                (lower_right_chunk.x + VECTOR_TILESIZE.x / 2, lower_right_chunk.y + VECTOR_TILESIZE.y * self.CHUNK_SIZE),
                (lower_left_chunk.x - VECTOR_TILESIZE.x * ((self.CHUNK_SIZE / 2) - 0.5), lower_left_chunk.y + VECTOR_TILESIZE.y * (self.CHUNK_SIZE / 2)),
            ), 2
        )
        
    def get_rendered_chunks(self) -> list[str]:
        response = []

        for y in range(int(self.selected_chunk.y) - self.RENDER_DISTANCE, int(self.selected_chunk.y) + self.RENDER_DISTANCE + 1):
            for x in range(int(self.selected_chunk.x) - self.RENDER_DISTANCE, int(self.selected_chunk.x) + self.RENDER_DISTANCE + 1):
                response.append(f'{x},{y}')
                
        return response