from src.game.chunk_manager import ChunkManager

from src.groups.entity_group import EntityGroup
from src.entity.tile import Tile

from src.constants import VECTOR_TILESIZE

from pygame.math import Vector2
from pygame import Surface
import pygame

class TilesManager:
    def __init__(self) -> None:
        self.tiles_group = EntityGroup()
        
    def add_tile(self, sprite: str, position: Vector2):
        new_tile = Tile(sprite, position)
        self.tiles_group.add(new_tile)
        
    def draw_selected(self, vector_selected_screen: Vector2, display: pygame.Surface):
        pygame.draw.polygon(
            display, 
            (255, 0, 0), 
            (
                (vector_selected_screen.x + VECTOR_TILESIZE.x / 2, vector_selected_screen.y),
                (vector_selected_screen.x + VECTOR_TILESIZE.x, vector_selected_screen.y + VECTOR_TILESIZE.y / 2),
                (vector_selected_screen.x + VECTOR_TILESIZE.x / 2, vector_selected_screen.y + VECTOR_TILESIZE.y),
                (vector_selected_screen.x, vector_selected_screen.y + VECTOR_TILESIZE.y / 2),
            ), 3
        )
    
    def define_rendered_tiles(self, chunk_manager: ChunkManager):
        self.tiles_group.empty()
        self.object_points = []
        rendered_chunks = chunk_manager.get_rendered_chunks()
        
        for chunk_str in rendered_chunks:
            if chunk_str in chunk_manager.map_dict:
                
                chunk = chunk_manager.map_dict[chunk_str]
                
                for row in range(len(chunk)):
                    for col in range(len(chunk[0])):
                        
                        if len(chunk[row]) > col:
                            chunk_data = chunk[row][col]

                            self.add_tile(chunk_data[0], chunk_data[2])
                            
    def draw(self, offset: Vector2, surface: Surface) -> None:
        self.tiles_group.draw(offset, surface)