import pygame
from src.constants import VECTOR_TILESIZE
from pygame.math import Vector2

class Tree(pygame.sprite.Sprite):
    def __init__(self, sprite: str, position: Vector2) -> None:
        super().__init__()
        
        self.image = pygame.image.load(sprite).convert_alpha()
        self.image = pygame.transform.scale(self.image, (VECTOR_TILESIZE.x, VECTOR_TILESIZE.y * 4))
        self.pos = position
        
        self.rect = self.image.get_rect(center = self.pos)