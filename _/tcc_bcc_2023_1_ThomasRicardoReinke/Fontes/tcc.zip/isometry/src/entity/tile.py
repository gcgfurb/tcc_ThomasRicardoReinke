import pygame
from pygame.math import Vector2

class Tile(pygame.sprite.Sprite):
    def __init__(self, sprite: str, position: Vector2) -> None:
        super().__init__()
        
        self.image = sprite
        self.pos = position
        
        self.rect = self.image.get_rect(topleft = self.pos)
