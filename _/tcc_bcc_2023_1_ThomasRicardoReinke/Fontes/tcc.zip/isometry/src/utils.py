import pygame
from pygame.math import Vector2
from src.constants import *
import numpy as np


def sign(p1: Vector2, p2: Vector2, p3: Vector2):
    return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y)
    
def is_point_inside(point: Vector2, vertice_a: Vector2, vertice_b: Vector2, vertice_c: Vector2):

    d1 = sign(point, vertice_a, vertice_b)
    d2 = sign(point, vertice_b, vertice_c)
    d3 = sign(point, vertice_c, vertice_a)

    has_neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    has_pos = (d1 > 0) or (d2 > 0) or (d3 > 0)

    return not (has_neg and has_pos)

def to_screen_coordinates(x: int, y: int, offset: Vector2):
    return Vector2(
        (VECTOR_ORIGIN.x * VECTOR_TILESIZE.x) + (x - y) * (VECTOR_TILESIZE.x / 2) + offset.x,
        (VECTOR_ORIGIN.y * VECTOR_TILESIZE.y) + (x + y) * (VECTOR_TILESIZE.y / 2) + offset.y,
    )
    
def to_list_coordinates(x, y):
    return Vector2(
        int((y - VECTOR_ORIGIN.y) + (x - VECTOR_ORIGIN.x)),
        int((y - VECTOR_ORIGIN.y) - (x - VECTOR_ORIGIN.x))
    )


 
