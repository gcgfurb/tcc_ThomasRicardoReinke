import time

import cProfile

from wave_function_collapse import WaveFunctionCollapse

if __name__ == '__main__':
    
    wave_function = WaveFunctionCollapse()
    
    dimensions = [5, 10, 25, 50, 75, 100]
    
    for d in dimensions:
        total = 0
        for i in range(50):
            start_time = time.time()
            map_array = wave_function.run(d, d)
            tempo = (time.time() - start_time) * 1000
            print(f'    {i}: {tempo} milissegundos ---')
            total += tempo
        print(f'{d}x{d}')
        print(f'--- {total / 50} milissegundos ---')
        print('')