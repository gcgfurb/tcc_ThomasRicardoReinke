class TileObject:
    def __init__(self, top: str, right: str, bottom: str, left: str, sprite: str) -> None:
        self.top = top
        self.right = right
        self.bottom = bottom
        self.left = left
        self.sprite = sprite