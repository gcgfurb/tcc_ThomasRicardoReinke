from random import shuffle, choices
from collections import namedtuple

class WaveFunctionCollapse:
    def __init__(self):
        self.adjacencies = namedtuple("Adjacencies", "top right bottom left sprite")
        self.file_lookup_table = {
            "water_bottom": ("GGG", "GGA", "AAA", "AGG"),
            "water_right": ("GGA", "AAA", "AGG", "GGG"),
            "water_left": ("AGG", "GGG", "GGA", "AAA"),
            "water_top": ("AAA", "AGG", "GGG", "GGA"),
    
            "water_top_right": ("AAA", "AAA", "AGG", "GGA"),
            "water_top_left": ("AAA", "AGG", "GGA", "AAA"),
            "water_bottom_right": ("GGA", "AAA", "AAA", "AGG"),
            "water_bottom_left": ("AGG", "GGA", "AAA", "AAA"),

            "grass_bottom_left": ("GGA", "AGG", "GGG", "GGG"),
            "grass_bottom_right": ("AGG", "GGG", "GGG", "GGA"),
            "grass_top_left": ("GGG", "GGA", "AGG", "GGG"),
            "grass_top_right": ("GGG", "GGG", "GGA", "AGG"),

            "grass": ("GGG", "GGG", "GGG", "GGG"),
            "water": ("AAA", "AAA", "AAA", "AAA"),
        }
        
        self.file_lookup_table_weights = {
            "water_bottom": 10,
            "water_right": 10,
            "water_left": 10,
            "water_top": 10,
    
            "water_top_right": 10,
            "water_top_left": 10,
            "water_bottom_right": 10,
            "water_bottom_left": 10,

            "grass_bottom_left": 10,
            "grass_bottom_right": 10,
            "grass_top_left": 10,
            "grass_top_right": 10,
    
            "grass": 900,
            "water": 500,
        }
        
    def get_tiles(self):
        tiles = {}

        for filename in self.file_lookup_table:
            sides = self.file_lookup_table[filename]

            tiles[filename] = self.adjacencies(*sides, filename)

        return tiles
        
    def find_possible_neighbors(self, x, y) -> set:
        return {(x, y - 1), (x + 1, y), (x, y + 1), (x - 1, y)}

    def find_entropy(self, x, y):
        localset = set()
        outset = set()

        # top
        if (x, y - 1) in self.filled_set:
            ref = self.board[y - 1][x]
            if ref is not None:
                ref = ref.bottom[::-1]
                localset = {tile for tile in self.tiles if self.tiles[tile].top == ref}
        else:
            localset = set(self.tiles)

        outset = localset

        # right
        if (x + 1, y) in self.filled_set:
            ref = self.board[y][x + 1]
            if ref is not None:
                ref = ref.left[::-1]
                localset = {tile for tile in self.tiles if self.tiles[tile].right == ref}
        else:
            localset = set(self.tiles)

        outset &= localset

        # bottom
        if (x, y + 1) in self.filled_set:
            ref = self.board[y + 1][x]
            if ref is not None:
                ref = ref.top[::-1]
                localset = {tile for tile in self.tiles if self.tiles[tile].bottom == ref}
        else:
            localset = set(self.tiles)

        outset &= localset

        # left
        if (x - 1, y) in self.filled_set:
            ref = self.board[y][x - 1]
            if ref is not None:
                ref = ref.right[::-1]
                localset = {tile for tile in self.tiles if self.tiles[tile].left == ref}
        else:
            localset = set(self.tiles)

        outset &= localset

        return (len(outset), (x, y), outset)
    
    def initialize(self, x: int, y: int):
        self.x = x
        self.y = y
        self.board = [ [None for j in range(x)] for i in range(y) ]
        self.filled_set = set()
        
        self.tiles = self.get_tiles()
        
    def get_weights(self, selected):
        return [self.file_lookup_table_weights[filename] for filename in selected if filename in self.file_lookup_table_weights]

    def run(self, x: int, y: int) -> list[list[namedtuple]]:
        
        self.initialize(x, y)
        empty_tile = {(0, 0)}
            
        while self.x * self.y > len(self.filled_set):
            to_go_through = set()
            
            for tile in self.filled_set:
                to_go_through |= self.find_possible_neighbors(*tile)
                
            to_go_through -= self.filled_set
            
            if not to_go_through:
                to_go_through = empty_tile

            entropies = [ self.find_entropy(*tile) for tile in to_go_through if (0 <= tile[0] < self.x) and (0 <= tile[1] < self.y) ]
            entropies.sort()
            entropies = [ tile for tile in entropies if tile[0] == entropies[0][0] ]
            
            shuffle(entropies)
            entropy = entropies[0]
            
            xy = entropy[1]
            entropy = list(entropy[2])
            
            if not entropy:
                return False
            
            weights = self.get_weights(entropy)
            entropy = choices(entropy, weights)
                        
            self.board[xy[1]][xy[0]] = self.tiles[entropy[0]]
            self.filled_set.add(xy)
                        
        return self.board
    
if __name__ == '__main__':
    wave_function = WaveFunctionCollapse()
    wave_function.run(5, 5)